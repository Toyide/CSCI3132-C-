CSCI3132 A3
Yide Ge B00639491

Compiler command:

	gcc -std=c++11 *.cpp -lstdc++ -o run