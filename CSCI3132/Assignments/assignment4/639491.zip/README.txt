CSCI 3132 A4
Yide Ge B00639491

please run it with command:

	g++ -std=c++11 testVector.cpp -o test